from .viewsetup import ViewSetupDialog
from .tagedit import TagEditDialog
from .enhance import EnhanceHistDialog
